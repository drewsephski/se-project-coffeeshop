# Triple Peaks Coffee Shop

This project is the second assignment in the Software Engineering program at TripleTen, created using HTML and CSS following a design brief.

## Features

- Uses Semantic HTML5
- Implements Flexbox for layout
- Various positioning techniques
- Organized with a flat BEM file structure
- Includes a custom form
- Features CSS animations and transformations
